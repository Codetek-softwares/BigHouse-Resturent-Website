let cart = [];
let wishlist = [];

function addToCart(id, name, price, image) {
    const existingItem = cart.find(item => item.id === id);
    if (existingItem) {
        existingItem.quantity++;
    } else {
        cart.push({ id, name, price, image, quantity: 1 });
    }
    saveCart();
    updateCartIndicator();
}

function addToWishlist(id, name, price, image) {
    if (!wishlist.find(item => item.id === id)) {
        wishlist.push({ id, name, price, image });
        saveWishlist();
        updateWishlistIndicator();
    }
}

function removeFromCart(id) {
    cart = cart.filter(item => item.id !== id);
    saveCart();
    renderCart();
    updateCartIndicator();
}

function moveToWishlist(id) {
    const item = cart.find(item => item.id === id);
    removeFromCart(id);
    addToWishlist(item.id, item.name, item.price, item.image);
}

function removeFromWishlist(id) {
    wishlist = wishlist.filter(item => item.id !== id);
    saveWishlist();
    renderWishlist();
    updateWishlistIndicator();
}

function moveToCartFromWishlist(id) {
    const item = wishlist.find(item => item.id === id);
    removeFromWishlist(id);
    addToCart(item.id, item.name, item.price, item.image);
}

function updateCartIndicator() {
    document.getElementById('cart-indicator').textContent = cart.length;
}

function updateWishlistIndicator() {
    document.getElementById('wishlist-indicator').textContent = wishlist.length;
}

function saveCart() {
    localStorage.setItem('cart', JSON.stringify(cart));
}

function saveWishlist() {
    localStorage.setItem('wishlist', JSON.stringify(wishlist));
}

function loadCart() {
    const storedCart = localStorage.getItem('cart');
    if (storedCart) {
        cart = JSON.parse(storedCart);
    }
}

function loadWishlist() {
    const storedWishlist = localStorage.getItem('wishlist');
    if (storedWishlist) {
        wishlist = JSON.parse(storedWishlist);
    }
}

function renderCart() {
    const cartItemsContainer = document.querySelector('.cart-items');
    const totalAmount = document.getElementById('total-amount');
    cartItemsContainer.innerHTML = '';
    let total = 0;

    cart.forEach(item => {
        const cartItem = document.createElement('div');
        cartItem.classList.add('cart-item');
        cartItem.innerHTML = `
            <img src="${item.image}" alt="${item.name}">
            <h2>${item.name}</h2>
            <p>Rs.${item.price}</p>
            <div class="quantity">
                <button onclick="decrementQuantity(${item.id})">-</button>
                <span>${item.quantity}</span>
                <button onclick="incrementQuantity(${item.id})">+</button>
            </div>
            <button onclick="removeFromCart(${item.id})">Remove</button>
            <button onclick="moveToWishlist(${item.id})">Add to Wishlist</button>
        `;
        cartItemsContainer.appendChild(cartItem);
        total += item.price * item.quantity;
    });

    totalAmount.textContent = total;
}

function renderWishlist() {
    const wishlistItemsContainer = document.querySelector('.wishlist-items');
    wishlistItemsContainer.innerHTML = '';

    wishlist.forEach(item => {
        const wishlistItem = document.createElement('div');
        wishlistItem.classList.add('wishlist-item');
        wishlistItem.innerHTML = `
            <img src="${item.image}" alt="${item.name}">
            <h2>${item.name}</h2>
            <p>Rs.${item.price}</p>
            <button onclick="removeFromWishlist(${item.id})">Remove</button>
            <button onclick="moveToCartFromWishlist(${item.id})">Add to Cart</button>
        `;
        wishlistItemsContainer.appendChild(wishlistItem);
    });
}

function incrementQuantity(id) {
    const item = cart.find(item => item.id === id);
    if (item) {
        item.quantity++;
        saveCart();
        renderCart();
    }
}

function decrementQuantity(id) {
    const item = cart.find(item => item.id === id);
    if (item && item.quantity > 1) {
        item.quantity--;
        saveCart();
        renderCart();
    } else if (item && item.quantity === 1) {
        removeFromCart(id);
    }
}

function checkout() {
    window.location.href = 'checkout.html';
}

document.addEventListener('DOMContentLoaded', () => {
    loadCart();
    loadWishlist();
    updateCartIndicator();
    updateWishlistIndicator();
    if (document.querySelector('.cart-items')) {
        renderCart();
    }
    if (document.querySelector('.wishlist-items')) {
        renderWishlist();
    }
});
